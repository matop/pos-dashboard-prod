import { useState } from 'react';

export interface TimeRange {
  from: number; // YYYYMMDD
  to: number;   // YYYYMMDD
}

function dateToKey(d: Date): number {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return parseInt(`${y}${m}${day}`);
}

function keyToInputValue(key: number): string {
  const s = String(key);
  return `${s.slice(0, 4)}-${s.slice(4, 6)}-${s.slice(6, 8)}`;
}

function inputValueToKey(val: string): number {
  return parseInt(val.replace(/-/g, ''));
}
function getPreset(days: number, refDate: string | null): TimeRange {
  const to = refDate
    ? new Date(parseInt(refDate.slice(0,4)), parseInt(refDate.slice(4,6))-1, parseInt(refDate.slice(6,8)))
    : new Date();
  const from = new Date(to);
  from.setDate(to.getDate() - days + 1);
  return { from: dateToKey(from), to: dateToKey(to) };
}

function getThisYear(refDate: string | null): TimeRange {
  const to = refDate
    ? new Date(parseInt(refDate.slice(0,4)), parseInt(refDate.slice(4,6))-1, parseInt(refDate.slice(6,8)))
    : new Date();
  const from = new Date(to.getFullYear(), 0, 1);
  return { from: dateToKey(from), to: dateToKey(to) };
}

// 3. PRESETS pasa a ser una función que recibe refDate
function getPresets(refDate: string | null) {
  return [
    { label: 'Últimos 7 días',  fn: () => getPreset(7,  refDate) },
    { label: 'Últimos 30 días', fn: () => getPreset(30, refDate) },
    { label: 'Últimos 90 días', fn: () => getPreset(90, refDate) },
    { label: 'Este año',        fn: () => getThisYear(refDate) },
  ];
}

// 1. Props — agregar refDate
interface Props {
  value: TimeRange;
  onChange: (range: TimeRange, label: string | null) => void;
  refDate: string | null; // ← nuevo
}

// 4. Componente recibe y usa refDate
export default function TimeRangeFilter({ value, onChange, refDate }: Props) {
  const [custom, setCustom] = useState(false);
  const presets = getPresets(refDate); // ← dinámico

  function applyPreset(label: string, fn: () => TimeRange) {
    setCustom(false);
    onChange(fn(), label);
  }

  return (
    // ... igual que antes pero usando `presets` en lugar de `PRESETS`
    <div className="flex flex-wrap items-center gap-2">
      <span className="text-xs font-medium" style={{ color: 'var(--text-muted)' }}>Período:</span>
      {presets.map(p => (
        <button key={p.label} onClick={() => applyPreset(p.label, p.fn)} className="filter-pill">
          {p.label}
        </button>
      ))}
      <button
        onClick={() => setCustom(v => !v)}
        className={`filter-pill ${custom ? 'active' : ''}`}
      >
        Personalizado
      </button>
      {custom && (
        <div className="flex items-center gap-2">
          <input
            type="date"
            value={keyToInputValue(value.from)}
            onChange={e => onChange({ ...value, from: inputValueToKey(e.target.value) }, null)}
            className="text-xs rounded-lg px-3 py-1.5 font-mono"
            style={{
              background: 'var(--bg-input)',
              border: '1px solid var(--border-input)',
              color: 'var(--text-mid)',
              outline: 'none',
            }}
          />
          <span style={{ color: 'var(--text-very-muted)' }}>—</span>
          <input
            type="date"
            value={keyToInputValue(value.to)}
            max={refDate ? keyToInputValue(Number(refDate)) : undefined}
            onChange={e => {
                const newTo = inputValueToKey(e.target.value);
                const maxTo = refDate ? parseInt(refDate) : 99991231;
              if (newTo > maxTo) return; // ← ignora el cambio si supera el corte
              onChange({ ...value, to: newTo }, null);
              }}
            className="text-xs rounded-lg px-3 py-1.5 font-mono"
            style={{
              background: 'var(--bg-input)',
              border: '1px solid var(--border-input)',
              color: 'var(--text-mid)',
              outline: 'none',
            }}
          />
        </div>
      )}
    </div>
  );
}
