import { Pool } from 'pg';
import dotenv from 'dotenv';


dotenv.config();

if (!process.env.DATABASE_URL) {
  console.log(process.env.DATABASE_URL);
  console.error('[DB] FATAL: La variable de entorno DATABASE_URL no está configurada.');
  process.exit(1);
}

export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  // Forzar SSL en producción para encriptar la conexión con la DB
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
  // Límites del pool de conexiones
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
});

pool.on('error', (err) => {
  console.error('[DB] Error inesperado en el pool de conexiones:', err.message);
});
