import { Router, Request, Response } from 'express';
import { pool } from '../db';
import { validateEmpkey, parseProductKeys, parseRefDate } from '../middleware/validate';

const router = Router();

/**
 * Convierte una fecha a su clave numérica YYYYMMDD.
 * dwphorakey tiene formato YYYYMMDDHH, por lo que:
 *   - dwphorakey / 100  → YYYYMMDD  (día)
 *   - dwphorakey % 100  → HH        (hora, 0-23)
 */
function toDayKey(date: Date): number {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return parseInt(`${y}${m}${d}`);
}


// GET /api/charts/sales-comparison?empkey=X&ubicod=Y&products=1,2,3
router.get('/', validateEmpkey, async (req: Request, res: Response) => {
  const empkey = (req as any).empkeyParsed as number;
  const { ubicod, refDate: refDateRaw, products } = req.query as Record<string, string>;

  const refDateParsed = parseRefDate(refDateRaw, res);
  if (refDateParsed === 'invalid') return;

  const now = refDateParsed ?? new Date();
  // 2. isToday compara contra el día REAL del servidor
  const realNow = new Date();
  const isToday = (anchorDayKey: number) => anchorDayKey === toDayKey(realNow);
  // 3. currentHour siempre del servidor rea
  const currentHour = realNow.getHours();
  
  // Puntos de comparación histórica
  const minusOneDay   = new Date(now); minusOneDay.setDate(now.getDate() - 1);
  const minusOneWeek  = new Date(now); minusOneWeek.setDate(now.getDate() - 7);
  const minusOneMonth = new Date(now); minusOneMonth.setMonth(now.getMonth() - 1);
  const minusOneYear  = new Date(now); minusOneYear.setFullYear(now.getFullYear() - 1);

  const anchors = [
    { label: 'Hoy',          dayKey: toDayKey(now) },
    { label: 'Ayer',         dayKey: toDayKey(minusOneDay) },
    { label: 'Hace 1 semana', dayKey: toDayKey(minusOneWeek) },
    { label: 'Hace 1 mes',   dayKey: toDayKey(minusOneMonth) },
    { label: 'Hace 1 año',   dayKey: toDayKey(minusOneYear) },
  ];

  const baseParams: unknown[] = [empkey];
  const extraConditions: string[] = [];

  // Validar ubicod
  if (ubicod) {
    const trimmed = ubicod.trim();
    if (trimmed.length > 50) {
      res.status(400).json({ error: 'ubicod inválido' });
      return;
    }
    baseParams.push(trimmed);
    extraConditions.push(`TRIM(r.dwpubicod) = $${baseParams.length}`);
  }

  // Validar productos
  const productKeys = parseProductKeys(products);
  if (productKeys.length > 0) {
    baseParams.push(productKeys);
    extraConditions.push(`r.dwpproductokey = ANY($${baseParams.length})`);
  }

  const extraWhere = extraConditions.length > 0
    ? 'AND ' + extraConditions.join(' AND ')
    : '';

  try {
    // ✅ DESPUÉS — hora solo para "Hoy", día completo para el resto
        const results = await Promise.all(
          anchors.map(async ({ label, dayKey }) => {
            const params = [...baseParams, dayKey];

            const hourCondition = isToday(dayKey)
              ? `AND (r.dwphorakey % 100) <= ${currentHour}`
              : '';

          const r = await pool.query(
            `SELECT COALESCE(SUM(r.dwptotalmonto), 0) AS total
            FROM dwpreporte r
            WHERE r.dwpempkey = $1
              ${extraWhere}
              AND (r.dwphorakey / 100) = $${params.length}
              ${hourCondition}`,
            params
          );
          return { label, total: Number(r.rows[0]?.total ?? 0) };
        })
      );

    res.json({ data: results, currentHour });
  } catch (e: any) {
    console.error('[salesComparison] Error en consulta:', e.message);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
});

export default router;
