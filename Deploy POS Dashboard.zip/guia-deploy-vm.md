# Guía de Deploy — POS Dashboard en VM Debian 12

Stack: **Node.js 22 + PostgreSQL + Nginx + PM2**  
Arquitectura: `Browser → Nginx (80) → React (dist/) + Node.js API (3001) → PostgreSQL`

---

## Prerequisitos

- VM Debian 12 con IP estática
- PostgreSQL ya instalado y corriendo
- Acceso SSH como root
- Código fuente en máquina local (carpetas `backend/` y `frontend/`)

---

## Paso 1 — Resolver clave GPG de PostgreSQL (si aplica)

Si `apt update` falla con `NO_PUBKEY 7FCC7D46ACCC4CF8`:

```bash
curl -fsSL https://www.postgresql.org/media/keys/ACCC4CF8.asc | sudo gpg --dearmor -o /usr/share/keyrings/postgresql.gpg

sudo sed -i 's|deb http://apt.postgresql.org/pub/repos/apt|deb [signed-by=/usr/share/keyrings/postgresql.gpg] http://apt.postgresql.org/pub/repos/apt|' /etc/apt/sources.list.d/pgdg.list

sudo rm -rf /var/lib/apt/lists/*
sudo apt update --ignore-missing
```

---

## Paso 2 — Instalar Node.js 22

```bash
curl -fsSL https://deb.nodesource.com/setup_22.x -o nodesource_setup.sh
sudo -E bash nodesource_setup.sh
sudo apt install -y nodejs
```

Verificar:
```bash
node -v    # v22.x.x
npm -v     # 10.x.x
```

---

## Paso 3 — Instalar Nginx

Si Apache2 está corriendo en el puerto 80, desactivarlo primero:

```bash
sudo systemctl stop apache2
sudo systemctl disable apache2
```

Instalar y arrancar Nginx:

```bash
sudo apt install -y nginx
sudo systemctl enable nginx
sudo systemctl start nginx
sudo systemctl status nginx   # debe mostrar: active (running)
```

Verificar en browser: `http://[IP-DE-TU-VM]` → página default de Nginx.

---

## Paso 4 — Instalar PM2

```bash
sudo npm install -g pm2
pm2 -v
```

---

## Paso 5 — Crear estructura de carpetas

```bash
sudo mkdir -p /var/www/pos-dashboard
sudo chown -R $USER:$USER /var/www/pos-dashboard
```

---

## Paso 6 — Subir el código (desde máquina local)

```bash
scp -r /ruta/local/backend root@[IP-VM]:/var/www/pos-dashboard/
scp -r /ruta/local/frontend root@[IP-VM]:/var/www/pos-dashboard/
```

> También se puede usar FileZilla o WinSCP apuntando a `/var/www/pos-dashboard/`

Verificar en la VM:
```bash
ls /var/www/pos-dashboard/
# backend/   frontend/
```

---

## Paso 7 — Configurar el Backend

### Instalar dependencias

```bash
cd /var/www/pos-dashboard/backend
npm install
```

### Generar API Secret Key

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Copiar el resultado para usarlo en el siguiente paso.

### Crear archivo `.env`

```bash
nano /var/www/pos-dashboard/backend/.env
```

```env
PORT=3001
NODE_ENV=production
DATABASE_URL=postgresql://postgres:TU_PASSWORD@localhost:5432/pos2407
API_SECRET_KEY=PEGAR_CLAVE_GENERADA_ARRIBA
FRONTEND_URL=http://[IP-DE-TU-VM]
```

Guardar: `Ctrl+O` → Enter → `Ctrl+X`

### Ajustes requeridos en el código para producción

**`src/db.ts`** — permitir certificado SSL autofirmado de PostgreSQL:
```ts
// Cambiar rejectUnauthorized: true → false
ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
```

**`src/index.ts`** — agregar trust proxy para Nginx (justo después de `const app = express()`):
```ts
const app = express();
app.set('trust proxy', 1); // requerido cuando hay Nginx como reverse proxy
```

### Build del backend

```bash
cd /var/www/pos-dashboard/backend
npm run build
```

---

## Paso 8 — Configurar el Frontend

### Instalar dependencias

```bash
cd /var/www/pos-dashboard/frontend
npm install
```

### Crear archivo `.env`

```bash
nano /var/www/pos-dashboard/frontend/.env
```

```env
VITE_API_SECRET_KEY=LA_MISMA_CLAVE_QUE_EN_EL_BACKEND
```

> ⚠️ Debe ser exactamente la misma clave que `API_SECRET_KEY` del backend.

### Build del frontend

```bash
npm run build
```

Esto genera la carpeta `dist/` con los archivos estáticos listos para Nginx.

---

## Paso 9 — Configurar Nginx como reverse proxy

```bash
sudo nano /etc/nginx/sites-available/pos-dashboard
```

```nginx
server {
    listen 80;
    server_name [IP-DE-TU-VM];

    # Frontend — archivos estáticos de React
    root /var/www/pos-dashboard/frontend/dist;
    index index.html;

    # SPA fallback — todas las rutas van a index.html
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Backend — proxy inverso a Node.js
    location /api/ {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

Activar el sitio:

```bash
sudo ln -s /etc/nginx/sites-available/pos-dashboard /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t        # debe mostrar: syntax is ok / test is successful
sudo systemctl reload nginx
```

---

## Paso 10 — Levantar el backend con PM2

```bash
cd /var/www/pos-dashboard/backend
pm2 start dist/index.js --name pos-backend
pm2 save
pm2 startup
```

`pm2 startup` configura el autoarranque al reiniciar la VM automáticamente vía systemd.

Verificar estado:
```bash
pm2 status
# pos-backend debe aparecer como: online
```

---

## Paso 11 — Verificar el deploy

Abrir en browser:
```
http://[IP-DE-TU-VM]/?empkey=TU_EMPKEY
```

El dashboard debe cargar con datos.

Revisar logs si hay errores:
```bash
pm2 logs pos-backend --lines 50
# Ctrl+C para salir del modo streaming
```

---

## Comandos útiles post-deploy

```bash
# Ver estado de procesos
pm2 status

# Reiniciar backend (después de cambios)
pm2 restart pos-backend

# Ver logs en tiempo real
pm2 logs pos-backend

# Recargar Nginx (después de cambios en config)
sudo systemctl reload nginx

# Rebuild completo frontend + reinicio backend
cd /var/www/pos-dashboard/frontend && npm run build
cd /var/www/pos-dashboard/backend && npm run build && pm2 restart pos-backend
```

---

## Problemas frecuentes

| Error | Causa | Solución |
|-------|-------|----------|
| `NO_PUBKEY 7FCC7D46ACCC4CF8` | Clave GPG PostgreSQL faltante | Ver Paso 1 |
| Nginx no arranca | Puerto 80 ocupado (Apache2) | `systemctl stop apache2` |
| `self-signed certificate` | SSL de PostgreSQL rechazado | `rejectUnauthorized: false` en db.ts |
| `ERR_ERL_UNEXPECTED_X_FORWARDED_FOR` | Trust proxy no configurado | `app.set('trust proxy', 1)` en index.ts |
| `500` en todas las APIs | Backend no conecta a DB | Revisar `DATABASE_URL` en `.env` |
| `401` en todas las APIs | API Key no coincide entre `.env` | Verificar que ambas claves sean idénticas |
| Mirror sync error en apt | Mirror PostgreSQL sincronizando | `sudo rm -rf /var/lib/apt/lists/* && sudo apt update` |
