"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.pool = void 0;
const pg_1 = require("pg");
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
if (!process.env.DATABASE_URL) {
    console.log(process.env.DATABASE_URL);
    console.error('[DB] FATAL: La variable de entorno DATABASE_URL no está configurada.');
    process.exit(1);
}
exports.pool = new pg_1.Pool({
    connectionString: process.env.DATABASE_URL,
    // Forzar SSL en producción para encriptar la conexión con la DB
    ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
    // Límites del pool de conexiones
    max: 20,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 5000,
});
exports.pool.on('error', (err) => {
    console.error('[DB] Error inesperado en el pool de conexiones:', err.message);
});
