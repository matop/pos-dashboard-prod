"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const express_rate_limit_1 = __importDefault(require("express-rate-limit"));
const dotenv_1 = __importDefault(require("dotenv"));
const auth_1 = require("./middleware/auth");
const branches_1 = __importDefault(require("./routes/branches"));
const products_1 = __importDefault(require("./routes/products"));
const salesHistory_1 = __importDefault(require("./routes/salesHistory"));
const topProducts_1 = __importDefault(require("./routes/topProducts"));
const salesComparison_1 = __importDefault(require("./routes/salesComparison"));
dotenv_1.default.config();
const app = (0, express_1.default)();
app.set('trust proxy', 1);
const PORT = process.env.PORT || 3001;
// ─── 1. SEGURIDAD: Headers HTTP ─────────────────────────────────────────────
app.use((0, helmet_1.default)());
// ─── 2. SEGURIDAD: CORS restringido al frontend autorizado ───────────────────
const allowedOrigin = process.env.FRONTEND_URL;
if (!allowedOrigin) {
    console.error('[CORS] ADVERTENCIA: FRONTEND_URL no está configurada. CORS bloqueará todas las solicitudes.');
}
app.use((0, cors_1.default)({
    origin: allowedOrigin,
    methods: ['GET'], // Este backend solo necesita GET
    credentials: true,
}));
// ─── 3. SEGURIDAD: Rate Limiting ─────────────────────────────────────────────
const limiter = (0, express_rate_limit_1.default)({
    windowMs: 15 * 60 * 1000, // ventana de 15 minutos
    max: 100, // máximo 100 requests por IP por ventana
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Demasiadas solicitudes, por favor intente más tarde' },
});
app.use('/api/', limiter);
// ─── 4. PARSEO DE BODY ────────────────────────────────────────────────────────
app.use(express_1.default.json({ limit: '10kb' })); // Limitar tamaño del body
// ─── 5. AUTENTICACIÓN: Todas las rutas /api requieren API Key ────────────────
app.use('/api/', auth_1.authMiddleware);
// ─── 6. RUTAS ────────────────────────────────────────────────────────────────
app.use('/api/branches', branches_1.default);
app.use('/api/products', products_1.default);
app.use('/api/charts/sales-history', salesHistory_1.default);
app.use('/api/charts/top-products', topProducts_1.default);
app.use('/api/charts/sales-comparison', salesComparison_1.default);
// ─── 7. RUTA NO ENCONTRADA ───────────────────────────────────────────────────
app.use((_req, res) => {
    res.status(404).json({ error: 'Ruta no encontrada' });
});
// ─── 8. MANEJO GLOBAL DE ERRORES ─────────────────────────────────────────────
app.use((err, _req, res, _next) => {
    console.error('[ERROR GLOBAL]', err);
    res.status(500).json({ error: 'Error interno del servidor' });
});
// ─── 9. INICIO ───────────────────────────────────────────────────────────────
app.listen(PORT, () => {
    console.log(`Backend corriendo en http://localhost:${PORT}`);
    console.log(`Entorno: ${process.env.NODE_ENV || 'development'}`);
});
