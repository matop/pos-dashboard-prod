"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const db_1 = require("../db");
const validate_1 = require("../middleware/validate");
const router = (0, express_1.Router)();
// GET /api/products?empkey=X
router.get('/', validate_1.validateEmpkey, async (req, res) => {
    const empkey = req.empkeyParsed;
    try {
        const result = await db_1.pool.query(`SELECT dwpproductokey AS productokey, TRIM(dwpproductodescripcion) AS descripcion
       FROM dwpproducto
       WHERE dwpempkey = $1
       ORDER BY TRIM(dwpproductodescripcion)`, [empkey]);
        res.json({ products: result.rows });
    }
    catch (e) {
        console.error('[products] Error en consulta:', e.message);
        res.status(500).json({ error: 'Error interno del servidor' });
    }
});
exports.default = router;
