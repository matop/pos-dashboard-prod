"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const db_1 = require("../db");
const validate_1 = require("../middleware/validate");
const router = (0, express_1.Router)();
// GET /api/charts/top-products?empkey=X&ubicod=Y&from=YYYYMMDD&to=YYYYMMDD&products=1,2,3
router.get('/', validate_1.validateEmpkey, async (req, res) => {
    const empkey = req.empkeyParsed;
    const { ubicod, from, to, products } = req.query;
    const params = [empkey];
    const conditions = ['r.dwpempkey = $1'];
    // Validar ubicod
    if (ubicod) {
        const trimmed = ubicod.trim();
        if (trimmed.length > 50) {
            res.status(400).json({ error: 'ubicod inválido' });
            return;
        }
        params.push(trimmed);
        conditions.push(`TRIM(r.dwpubicod) = $${params.length}`);
    }
    // Validar fechas
    const fromDate = (0, validate_1.parseDateParam)(from, 'from', res);
    if (fromDate === 'invalid')
        return;
    if (fromDate !== null) {
        params.push(fromDate);
        conditions.push(`(r.dwphorakey / 100) >= $${params.length}`);
    }
    const toDate = (0, validate_1.parseDateParam)(to, 'to', res);
    if (toDate === 'invalid')
        return;
    if (toDate !== null) {
        params.push(toDate);
        conditions.push(`(r.dwphorakey / 100) <= $${params.length}`);
    }
    // Validar rango de fechas
    if (fromDate && toDate && fromDate > toDate) {
        res.status(400).json({ error: "El parámetro 'from' no puede ser mayor que 'to'" });
        return;
    }
    // Validar productos
    const productKeys = (0, validate_1.parseProductKeys)(products);
    if (productKeys.length > 0) {
        params.push(productKeys);
        conditions.push(`r.dwpproductokey = ANY($${params.length})`);
    }
    const where = 'WHERE ' + conditions.join(' AND ');
    try {
        const result = await db_1.pool.query(`SELECT r.dwpproductokey AS productokey,
              TRIM(p.dwpproductodescripcion) AS descripcion,
              SUM(r.dwptotalmonto) AS total
       FROM dwpreporte r
       LEFT JOIN dwpproducto p
         ON r.dwpproductokey = p.dwpproductokey AND r.dwpempkey = p.dwpempkey
       ${where}
       GROUP BY r.dwpproductokey, p.dwpproductodescripcion
       ORDER BY total DESC`, params);
        res.json({
            data: result.rows.map(row => ({
                productokey: Number(row.productokey),
                descripcion: row.descripcion || `Producto ${row.productokey}`,
                total: Number(row.total),
            })),
        });
    }
    catch (e) {
        console.error('[topProducts] Error en consulta:', e.message);
        res.status(500).json({ error: 'Error interno del servidor' });
    }
});
exports.default = router;
