"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const db_1 = require("../db");
const validate_1 = require("../middleware/validate");
const router = (0, express_1.Router)();
// GET /api/charts/sales-history?empkey=X&ubicod=Y&from=YYYYMMDD&to=YYYYMMDD&products=1,2,3
router.get('/', validate_1.validateEmpkey, async (req, res) => {
    const empkey = req.empkeyParsed;
    const { ubicod, from, to, products } = req.query;
    const params = [empkey];
    const conditions = ['r.dwpempkey = $1'];
    // Validar ubicod
    if (ubicod) {
        const trimmed = ubicod.trim();
        if (trimmed.length > 50) {
            res.status(400).json({ error: 'ubicod inválido' });
            return;
        }
        params.push(trimmed);
        conditions.push(`TRIM(r.dwpubicod) = $${params.length}`);
    }
    // Validar fechas
    const fromDate = (0, validate_1.parseDateParam)(from, 'from', res);
    if (fromDate === 'invalid')
        return;
    if (fromDate !== null) {
        params.push(fromDate);
        conditions.push(`(r.dwphorakey / 100) >= $${params.length}`);
    }
    const toDate = (0, validate_1.parseDateParam)(to, 'to', res);
    if (toDate === 'invalid')
        return;
    if (toDate !== null) {
        params.push(toDate);
        conditions.push(`(r.dwphorakey / 100) <= $${params.length}`);
    }
    // Validar rango de fechas
    if (fromDate && toDate && fromDate > toDate) {
        res.status(400).json({ error: "El parámetro 'from' no puede ser mayor que 'to'" });
        return;
    }
    // Validar productos
    const productKeys = (0, validate_1.parseProductKeys)(products);
    if (productKeys.length > 0) {
        params.push(productKeys);
        conditions.push(`r.dwpproductokey = ANY($${params.length})`);
    }
    const where = 'WHERE ' + conditions.join(' AND ');
    try {
        const result = await db_1.pool.query(`SELECT (r.dwphorakey / 100)::bigint AS day,
              SUM(r.dwptotalmonto) AS total
       FROM dwpreporte r
       ${where}
       GROUP BY (r.dwphorakey / 100)
       ORDER BY (r.dwphorakey / 100)`, params);
        res.json({
            data: result.rows.map(row => ({
                day: Number(row.day),
                total: Number(row.total),
            })),
        });
    }
    catch (e) {
        console.error('[salesHistory] Error en consulta:', e.message);
        res.status(500).json({ error: 'Error interno del servidor' });
    }
});
exports.default = router;
