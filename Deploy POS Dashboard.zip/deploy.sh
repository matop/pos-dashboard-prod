#!/bin/bash
# deploy.sh � pos-dashboard
set -e

echo "? [1/5] Instalando dependencias del backend (incluyendo devDeps para compilar)..."
cd /var/www/pos-dashboard/backend
npm install                    # instala TODO, incluyendo @types/*

echo "? [2/5] Compilando TypeScript..."
npx tsc

echo "? [3/5] Eliminando devDependencies del backend (solo producci�n)..."
npm prune --omit=dev           # limpia lo que no se necesita en runtime

echo "? [4/5] Reiniciando backend..."
pm2 restart pos-backend

echo "? [5/5] Compilando frontend..."
cd /var/www/pos-dashboard/frontend
npm install
npm run build

sudo systemctl reload nginx

echo "? Deploy completado"